import React, { useState, useEffect, useContext } from 'react';
import { StyleSheet, View, ScrollView, TouchableOpacity, Text, Alert, TextInput } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useAction, useMutation, useQuery } from 'convex/react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, spacing, radius, typography } from '../lib/theme';
import { api } from '../lib/config';
import { AuthContext } from '../lib/auth-context';
import * as ImagePicker from 'expo-image-picker';

type InspectionStatus = 'pass' | 'fail' | 'na';

interface ChecklistItem {
  id: string;
  item: string;
  status: InspectionStatus | null;
  comment: string;
  photoUris: string[];
}

interface AnalysisPhoto {
  uri: string;
  storageId: string;
  photoUrl: string;
}

interface AnalysisResult {
  itemId: string;
  item: string;
  status: InspectionStatus;
  confidence: number;
  summary: string;
  recommendation: string;
  requiresHumanReview: boolean;
  comparison?: {
    issuesDetected: boolean;
    comparisonSummary: string;
    changesFromPrevious: string[];
    aiRecommendation: string;
    confidenceLevel: number;
    requiresApproval: boolean;
  };
  photos: AnalysisPhoto[];
}

type TemplateChecklistItem = {
  id?: string;
  item: string;
};

const InspectionChecklistScreen = ({ route, navigation }: any) => {
  const { templateId, assetType, vehicleId, assetId } = route.params;
  const { user } = useContext(AuthContext);
  const [checklist, setChecklist] = useState<ChecklistItem[]>([]);
  const [overallComment, setOverallComment] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [analysisResults, setAnalysisResults] = useState<Record<string, AnalysisResult>>({});

  const templates = useQuery(
    api.inspections.getTemplates,
    user?.companyId ? { companyId: user.companyId as any } : 'skip'
  );

  const checklistItemIds = checklist.map((item: ChecklistItem) => item.id);
  const baselinePhotos = useQuery(
    api.inspections.getInspectionItemBaselines,
    user?.companyId && templateId && checklistItemIds.length > 0
      ? {
          companyId: user.companyId as any,
          templateId: templateId as any,
          checklistItemIds,
        }
      : 'skip'
  );

  const createInspection = useMutation(api.inspections.createInspection);
  const updateInspectionResults = useMutation(api.inspections.updateInspectionResults);
  const generateInspectionPhotoUploadUrl = useMutation(api.inspections.generateInspectionPhotoUploadUrl);
  const getInspectionPhotoUrl = useMutation(api.inspections.getInspectionPhotoUrl);
  const saveInspectionPhoto = useMutation(api.inspections.saveInspectionPhoto);
  const compareInspectionPhotos = useAction(api.inspections.compareInspectionPhotos);
  const analyzeChecklistItem = useAction(api.inspections.analyzeChecklistItem);

  useEffect(() => {
    const template = templates?.find((t: any) => String(t._id) === String(templateId));
    if (!template?.checklist?.length) {
      return;
    }

    setChecklist((prev: ChecklistItem[]) => {
      if (prev.length > 0) {
        return prev;
      }

      const checklistItems: ChecklistItem[] = (template.checklist as TemplateChecklistItem[]).map(
        (item: TemplateChecklistItem, index: number): ChecklistItem => ({
          id: item.id || String(index),
          item: item.item,
          status: null,
          comment: '',
          photoUris: [],
        })
      );

      return checklistItems;
    });
  }, [templateId, templates]);

  const updateChecklistItem = (itemId: string, field: string, value: any) => {
    setChecklist((prev: ChecklistItem[]) =>
      prev.map((item: ChecklistItem) =>
        item.id === itemId ? { ...item, [field]: value } : item
      )
    );
  };

  const addPhoto = async (itemId: string) => {
    try {
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled) {
        const photoUri = result.assets[0].uri;
        setChecklist((prev: ChecklistItem[]) =>
          prev.map((item: ChecklistItem) =>
            item.id === itemId ? { ...item, photoUris: [...item.photoUris, photoUri], status: null } : item
          )
        );
        setAnalysisResults({});
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to capture photo');
    }
  };

  const removePhoto = (itemId: string, photoIndex: number) => {
    setChecklist((prev: ChecklistItem[]) =>
      prev.map((item: ChecklistItem) =>
        item.id === itemId
          ? { ...item, photoUris: item.photoUris.filter((_, index) => index !== photoIndex), status: null }
          : item
      )
    );
    setAnalysisResults({});
  };

  const uploadPhoto = async (photoUri: string) => {
    const uploadUrl = await generateInspectionPhotoUploadUrl({});
    const response = await globalThis.fetch(photoUri);
    const blob = await response.blob();
    const uploadResponse = await globalThis.fetch(uploadUrl, {
      method: 'POST',
      headers: {
        'Content-Type': blob.type || 'image/jpeg',
      },
      body: blob,
    });

    if (!uploadResponse.ok) {
      throw new Error('Failed to upload photo');
    }

    return await uploadResponse.json();
  };

  const getAssetName = () => {
    if (assetType === 'vehicle') return 'Vehicle inspection';
    if (assetType === 'asset') return 'Equipment inspection';
    return 'General inspection';
  };

  const handleAnalyzeInspection = async () => {
    if (isAnalyzing || isSubmitting) {
      return;
    }

    try {
      setIsAnalyzing(true);
      const nextResults: Record<string, AnalysisResult> = {};

      for (const item of checklist) {
        const uploadedPhotos: AnalysisPhoto[] = [];

        for (const photoUri of item.photoUris) {
          const { storageId } = await uploadPhoto(photoUri);
          const photoUrl = await getInspectionPhotoUrl({ storageId });
          uploadedPhotos.push({ uri: photoUri, storageId, photoUrl });
        }

        const currentPhotoUrls = uploadedPhotos.map((photo) => photo.photoUrl);
        const aiAnalysis = await analyzeChecklistItem({
          itemName: item.item,
          assetType,
          assetName: getAssetName(),
          comment: item.comment || overallComment || undefined,
          photoUrls: currentPhotoUrls,
        });

        const baseline = baselinePhotos?.find((photo: { checklistItemId: string }) => photo.checklistItemId === item.id);
        let comparison: AnalysisResult['comparison'];

        if (currentPhotoUrls.length > 0 && baseline) {
          comparison = await compareInspectionPhotos({
            currentPhotoUrls,
            previousPhotoUrls: baseline.photoUrls || [baseline.photoUrl],
            checklistItemName: item.item,
            assetName: getAssetName(),
          });
        } else {
          comparison = {
            issuesDetected: aiAnalysis.recommendedStatus === 'fail',
            comparisonSummary: currentPhotoUrls.length > 0
              ? `${currentPhotoUrls.length} photo${currentPhotoUrls.length === 1 ? '' : 's'} analysed. No previous baseline found, so these can become the baseline after submission.`
              : 'No photo added. AI used comments only, so review carefully before sending.',
            changesFromPrevious: [],
            aiRecommendation: aiAnalysis.recommendation,
            confidenceLevel: aiAnalysis.confidence,
            requiresApproval: aiAnalysis.requiresHumanReview,
          };
        }

        nextResults[item.id] = {
          itemId: item.id,
          item: item.item,
          status: aiAnalysis.recommendedStatus,
          confidence: aiAnalysis.confidence,
          summary: aiAnalysis.summary,
          recommendation: aiAnalysis.recommendation,
          requiresHumanReview: aiAnalysis.requiresHumanReview,
          comparison,
          photos: uploadedPhotos,
        };
      }

      setAnalysisResults(nextResults);
      Alert.alert('Review AI Results', 'AI analysis is ready. Review the results and fix anything needed before sending to the manager.');
    } catch (error: any) {
      Alert.alert('Error', error?.message || 'Failed to analyse inspection');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSubmitInspection = async () => {
    if (isSubmitting || isAnalyzing) {
      return;
    }

    const results: AnalysisResult[] = Object.values(analysisResults);
    if (results.length !== checklist.length) {
      Alert.alert('Analyze first', 'Please run AI analysis and review the results before sending this inspection to the manager.');
      return;
    }

    try {
      setIsSubmitting(true);

      const checklistForSubmission: Array<{ itemId: string; item: string; status: InspectionStatus; comment?: string }> = checklist.map((item: ChecklistItem) => {
        const result = analysisResults[item.id];
        const finalStatus: InspectionStatus = item.status || result?.status || 'na';
        const summary = result
          ? `${result.summary}${result.recommendation ? ` Recommendation: ${result.recommendation}` : ''}${result.requiresHumanReview ? ' Manager review recommended.' : ''}`
          : undefined;

        return {
          itemId: item.id,
          item: item.item,
          status: finalStatus,
          comment: item.comment || summary || undefined,
        };
      });

      const failedItems = checklistForSubmission.filter((item) => item.status === 'fail');
      const reviewItems = results.filter((result) => result.requiresHumanReview || result.comparison?.requiresApproval);
      const followUpNotes = failedItems.length > 0 || reviewItems.length > 0
        ? `AI follow-up required. Failed item(s): ${failedItems.map((item) => item.item).join(', ') || 'none'}. Manager review item(s): ${reviewItems.map((item) => item.item).join(', ') || 'none'}.${overallComment ? ` ${overallComment}` : ''}`
        : undefined;

      const inspectionId = await createInspection({
        companyId: user?.companyId as any,
        templateId: templateId as any,
        inspectorId: user?.userId as any,
        assetType,
        vehicleId,
        assetId,
        checklist: checklistForSubmission,
        overallCondition: failedItems.length > 0 ? 'fail' : 'pass',
        comments: overallComment || undefined,
        isBaseline: !baselinePhotos || baselinePhotos.length === 0,
        followUpActionRequired: failedItems.length > 0 || reviewItems.length > 0,
        followUpNotes,
      });

      for (const item of checklist) {
        const result = analysisResults[item.id];
        const baseline = baselinePhotos?.find((photo: { checklistItemId: string }) => photo.checklistItemId === item.id);

        for (const [photoIndex, photo] of result.photos.entries()) {
          await saveInspectionPhoto({
            inspectionId,
            companyId: user?.companyId as any,
            templateId: templateId as any,
            checklistItemId: item.id,
            itemName: item.item,
            assetType,
            storageId: photo.storageId,
            isBaseline: !baseline,
            vehicleId,
            assetId,
            comment: item.comment || overallComment || undefined,
            caption: `${item.item} photo ${photoIndex + 1}`,
            angle: `photo_${photoIndex + 1}`,
            order: photoIndex,
          });
        }
      }

      await updateInspectionResults({
        inspectionId,
        checklist: checklistForSubmission,
        overallCondition: failedItems.length > 0 ? 'fail' : 'pass',
        comments: overallComment || undefined,
        followUpActionRequired: failedItems.length > 0 || reviewItems.length > 0,
        followUpNotes,
      });

      Alert.alert('Success', 'Inspection sent to manager');
      navigation.goBack();
    } catch (error: any) {
      Alert.alert('Error', error?.message || 'Failed to send inspection');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <MaterialIcons name="arrow-back" size={24} color={colors.primary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Inspection Checklist</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={typography.h4}>AI Inspection</Text>
          <View style={styles.autoFollowUpBox}>
            <MaterialIcons name="auto-awesome" size={22} color={colors.primary} />
            <Text style={styles.autoFollowUpText}>
              Take clear photos, run AI analysis, then review the results below. Nothing is sent to the manager until you press Send to Manager.
            </Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={typography.h4}>Inspection Items</Text>
          {checklist.map((item: ChecklistItem) => (
            <View key={item.id} style={styles.checklistItemContainer}>
              <Text style={[typography.body, { marginBottom: spacing.sm }]}>{item.item}</Text>

              <View style={styles.aiDecisionPlaceholder}>
                <MaterialIcons name="psychology" size={18} color={colors.primary} />
                <Text style={styles.aiDecisionText}>
                  {analysisResults[item.id]
                    ? `AI result: ${analysisResults[item.id].status.toUpperCase()} • ${analysisResults[item.id].confidence}% confidence`
                    : 'AI will review all angles you add and compare them with the baseline photos.'}
                </Text>
              </View>

              {analysisResults[item.id] && (
                <View style={styles.statusRow}>
                  {(['pass', 'fail', 'na'] as InspectionStatus[]).map((status) => (
                    <TouchableOpacity
                      key={status}
                      style={[
                        styles.statusButton,
                        (item.status || analysisResults[item.id].status) === status && styles.statusButtonActive,
                      ]}
                      onPress={() => updateChecklistItem(item.id, 'status', status)}
                    >
                      <Text style={[
                        styles.statusButtonText,
                        (item.status || analysisResults[item.id].status) === status && styles.statusButtonTextActive,
                      ]}>
                        {status.toUpperCase()}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              )}

              <TouchableOpacity
                style={styles.photoButton}
                onPress={() => addPhoto(item.id)}
              >
                <MaterialIcons name="camera-alt" size={20} color={colors.primary} />
                <Text style={[typography.small, { color: colors.primary }]}>
                  Add Another Angle{item.photoUris.length > 0 ? ` (${item.photoUris.length})` : ''}
                </Text>
              </TouchableOpacity>

              {item.photoUris.length > 0 && (
                <View style={styles.photoList}>
                  {item.photoUris.map((_, photoIndex) => (
                    <View key={`${item.id}-${photoIndex}`} style={styles.photoChip}>
                      <MaterialIcons name="photo" size={16} color={colors.success} />
                      <Text style={styles.photoChipText}>Photo {photoIndex + 1}</Text>
                      <TouchableOpacity onPress={() => removePhoto(item.id, photoIndex)}>
                        <MaterialIcons name="close" size={16} color={colors.textSecondary} />
                      </TouchableOpacity>
                    </View>
                  ))}
                </View>
              )}

              <TextInput
                style={styles.itemInput}
                placeholder="Add item note or explain what you fixed"
                placeholderTextColor={colors.textSecondary}
                value={item.comment}
                onChangeText={(text: string) => updateChecklistItem(item.id, 'comment', text)}
                multiline
              />

              {analysisResults[item.id] && (
                <View style={styles.comparisonBox}>
                  <Text style={styles.comparisonTitle}>AI Result Before Sending</Text>
                  <Text style={styles.comparisonText}>{analysisResults[item.id].summary}</Text>
                  <Text style={styles.comparisonText}>Recommendation: {analysisResults[item.id].recommendation}</Text>
                  {analysisResults[item.id].comparison && (
                    <Text style={styles.comparisonText}>Comparison: {analysisResults[item.id].comparison?.comparisonSummary}</Text>
                  )}
                  {(analysisResults[item.id].requiresHumanReview || analysisResults[item.id].comparison?.requiresApproval) && (
                    <Text style={styles.reviewText}>Manager review will be requested unless you fix this before sending.</Text>
                  )}
                </View>
              )}
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={typography.bodyMedium}>Optional Notes</Text>
          <TextInput
            style={[styles.input, { minHeight: 100, textAlignVertical: 'top' }]}
            placeholder="Add any context for the AI, if needed"
            placeholderTextColor={colors.textSecondary}
            value={overallComment}
            onChangeText={setOverallComment}
            multiline
          />
        </View>

        <View style={styles.section}>
          <View style={styles.autoFollowUpBox}>
            <MaterialIcons name="assignment-late" size={22} color={colors.warning} />
            <Text style={styles.autoFollowUpText}>
              If the AI finds a defect or unclear evidence, it will flag manager review and recommend follow-up actions automatically.
            </Text>
          </View>
        </View>

        <TouchableOpacity
          style={[styles.analyzeButton, (isAnalyzing || isSubmitting) && styles.submitButtonDisabled]}
          onPress={handleAnalyzeInspection}
          disabled={isAnalyzing || isSubmitting}
        >
          <MaterialIcons name="psychology" size={24} color={colors.background} />
          <Text style={[typography.body, { color: colors.background, fontWeight: '600' }]}> 
            {isAnalyzing ? 'Analysing...' : Object.keys(analysisResults).length > 0 ? 'Re-analyze After Fixes' : 'Analyze Inspection'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.submitButton, (isSubmitting || isAnalyzing || Object.keys(analysisResults).length === 0) && styles.submitButtonDisabled]}
          onPress={handleSubmitInspection}
          disabled={isSubmitting || isAnalyzing || Object.keys(analysisResults).length === 0}
        >
          <MaterialIcons name="send" size={24} color={colors.background} />
          <Text style={[typography.body, { color: colors.background, fontWeight: '600' }]}> 
            {isSubmitting ? 'Sending...' : 'Send to Manager'}
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    marginTop: spacing.sm,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: colors.primary,
  },
  content: {
    flex: 1,
    padding: spacing.lg,
  },
  section: {
    marginBottom: spacing.xl,
  },
  checklistItemContainer: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    marginTop: spacing.md,
  },
  aiDecisionPlaceholder: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceDark,
    marginVertical: spacing.md,
  },
  aiDecisionText: {
    ...typography.small,
    color: colors.text,
    flex: 1,
  },
  photoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.primary,
    borderStyle: 'dashed',
  },
  photoList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  photoChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.sm,
    borderRadius: radius.full,
    backgroundColor: colors.surfaceDark,
  },
  photoChipText: {
    ...typography.small,
    color: colors.text,
  },
  comparisonBox: {
    marginTop: spacing.md,
    padding: spacing.md,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceDark,
  },
  comparisonTitle: {
    ...typography.bodyMedium,
    color: colors.primary,
    marginBottom: spacing.xs,
  },
  comparisonText: {
    ...typography.body,
    color: colors.text,
    marginTop: spacing.xs,
  },
  reviewText: {
    ...typography.small,
    color: colors.warning,
    marginTop: spacing.sm,
    fontWeight: '600',
  },
  statusRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  statusButton: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: spacing.sm,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceDark,
    borderWidth: 1,
    borderColor: colors.border,
  },
  statusButtonActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  statusButtonText: {
    ...typography.small,
    color: colors.text,
    fontWeight: '600',
  },
  statusButtonTextActive: {
    color: colors.background,
  },
  itemInput: {
    backgroundColor: colors.surfaceDark,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    marginTop: spacing.md,
    minHeight: 56,
    color: colors.text,
    textAlignVertical: 'top',
  },
  toggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    marginTop: spacing.sm,
  },
  toggleActive: {
    backgroundColor: colors.surfaceDark,
  },
  autoFollowUpBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    padding: spacing.md,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  autoFollowUpText: {
    ...typography.bodyMedium,
    color: colors.text,
    flex: 1,
  },
  input: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    marginTop: spacing.sm,
  },
  analyzeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.md,
    backgroundColor: colors.primary,
    marginTop: spacing.lg,
    marginBottom: spacing.md,
  },
  submitButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.md,
    backgroundColor: colors.success,
    marginBottom: spacing.lg,
  },
  submitButtonDisabled: {
    backgroundColor: colors.textTertiary,
  },
});

export default InspectionChecklistScreen;